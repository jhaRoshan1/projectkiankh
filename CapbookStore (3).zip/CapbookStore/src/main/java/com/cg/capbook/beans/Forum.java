package com.cg.capbook.beans;
import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class Forum {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int forumId;
	private String forumName;
	private String forumDescription;
	private int forumAdmin;
	@OneToMany(mappedBy="forum",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer, ForumRequest>forumRequests;
	@OneToMany(mappedBy="forum",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private Map<Integer,ForumPost>forumPosts;
	@ManyToMany(mappedBy="forums",fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@MapKey
	private  Map<Integer,UserProfile>users;
	
	public Forum() {}

	public Forum(String forumName, String forumDescription, int forumAdmin, Map<Integer, ForumPost> forumPosts,
			Map<Integer, UserProfile> users) {
		super();
		this.forumName = forumName;
		this.forumDescription = forumDescription;
		this.forumAdmin = forumAdmin;
		this.forumPosts = forumPosts;
		this.users = users;
	}

	public Forum(String forumName, String forumDescription, int forumAdmin, Map<Integer, ForumPost> forumPosts) {
		super();
		this.forumName = forumName;
		this.forumDescription = forumDescription;
		this.forumAdmin = forumAdmin;
		this.forumPosts = forumPosts;
	}

	public int getForumId() {
		return forumId;
	}

	public void setForumId(int forumId) {
		this.forumId = forumId;
	}

	public String getForumName() {
		return forumName;
	}

	public void setForumName(String forumName) {
		this.forumName = forumName;
	}

	public String getForumDescription() {
		return forumDescription;
	}

	public void setForumDescription(String forumDescription) {
		this.forumDescription = forumDescription;
	}

	public int getForumAdmin() {
		return forumAdmin;
	}

	public void setForumAdmin(int forumAdmin) {
		this.forumAdmin = forumAdmin;
	}

	public Map<Integer, ForumPost> getForumPosts() {
		return forumPosts;
	}

	public void setForumPosts(Map<Integer, ForumPost> forumPosts) {
		this.forumPosts = forumPosts;
	}

	public Map<Integer, UserProfile> getUsers() {
		return users;
	}

	public void setUsers(Map<Integer, UserProfile> users) {
		this.users = users;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + forumAdmin;
		result = prime * result + ((forumDescription == null) ? 0 : forumDescription.hashCode());
		result = prime * result + forumId;
		result = prime * result + ((forumName == null) ? 0 : forumName.hashCode());
		result = prime * result + ((forumPosts == null) ? 0 : forumPosts.hashCode());
		result = prime * result + ((users == null) ? 0 : users.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Forum other = (Forum) obj;
		if (forumAdmin != other.forumAdmin)
			return false;
		if (forumDescription == null) {
			if (other.forumDescription != null)
				return false;
		} else if (!forumDescription.equals(other.forumDescription))
			return false;
		if (forumId != other.forumId)
			return false;
		if (forumName == null) {
			if (other.forumName != null)
				return false;
		} else if (!forumName.equals(other.forumName))
			return false;
		if (forumPosts == null) {
			if (other.forumPosts != null)
				return false;
		} else if (!forumPosts.equals(other.forumPosts))
			return false;
		if (users == null) {
			if (other.users != null)
				return false;
		} else if (!users.equals(other.users))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Forum [forumId=" + forumId + ", forumName=" + forumName + ", forumDescription=" + forumDescription
				+ ", forumAdmin=" + forumAdmin + ", forumPosts=" + forumPosts + ", users=" + users + "]";
	}
	
}
