package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.ForumLike;

public interface ForumLikeDao extends JpaRepository<ForumLike, Integer> {

}
