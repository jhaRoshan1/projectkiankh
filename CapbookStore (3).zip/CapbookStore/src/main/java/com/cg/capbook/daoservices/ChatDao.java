package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.Chat;

public interface ChatDao extends JpaRepository<Chat, Integer>{

}
