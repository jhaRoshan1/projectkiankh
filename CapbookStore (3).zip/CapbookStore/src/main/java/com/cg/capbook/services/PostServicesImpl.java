package com.cg.capbook.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.daoservices.PostDao;
import com.cg.capbook.daoservices.UserProfileDao;
import com.cg.capbook.exceptions.PostNotFoundException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;
@Component("postServices")
public class PostServicesImpl implements PostServices{

	Scanner sc=new Scanner(System.in);
	@Autowired
	UserProfileDao userProfileDao;
	@Autowired
	PostDao postDao;
	
	int index=0;
	@Override
	public Post acceptPost(String statusBody,Post post,UserProfile user) {
		//UserProfile user=userProfileDao.findByEmailId(emailId);
		/* String statusBody=sc.next(); */
		post.setStatusBody(statusBody);
		post.setLikeCount(0);
		post.setDislikeCount(0);
        post.setUser(user);
		postDao.save(post);
		//post.getPostId();

		return post;
	}


	public List<Post> findPostByUserId(Post post)
	{
		List<Post>posts = null;
		while(true)
		{
			
			/* posts.add(index, postDao.findById(post.getPostId())); */
			index++;
		}
		
	}
	public List<Post> findAllPosts(Post post)
	{
		return postDao.findAll();
	}


	public Post getPostProfileDetails(int postId)throws PostNotFoundException{
		return postDao.findById(postId).orElseThrow(()->new
				PostNotFoundException("Invalid post Id")); }


	public HashMap<Integer, Post> setUser(UserProfile user,Post post) throws
	UserProfileNotFoundException, PostNotFoundException {

		Map<Integer, Post>postMap=new HashMap<Integer, Post>(); 
		post.setUser(user);
		//postDao.save(post);
		Post post1=this.getPostProfileDetails(post.getPostId());
		postMap.put(post.getPostId(),post1);
		user.setPost(postMap); 
		return		(HashMap<Integer, Post>) postMap; 
		
	}



}
