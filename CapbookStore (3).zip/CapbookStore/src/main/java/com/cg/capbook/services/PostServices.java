package com.cg.capbook.services;

import java.util.HashMap;

import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.exceptions.PostNotFoundException;
import com.cg.capbook.exceptions.UserProfileNotFoundException;

public interface PostServices {

	
	
	  public HashMap<Integer, Post> setUser(UserProfile user,Post post) throws
	  UserProfileNotFoundException, PostNotFoundException;
	 
	//public Post acceptPost(String statusBody, Post post);

	public Post acceptPost(String statusBody, Post post, UserProfile user);
}
