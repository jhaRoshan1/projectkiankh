package com.cg.capbook.beans;
import java.time.LocalDateTime;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
@Entity
public class Messages{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int message_Id;
	private String text;
	private LocalDateTime date1=LocalDateTime.now();
	@ManyToOne
	private Chat chat;
	
	public Messages() {}
	
	public Messages(String text, LocalDateTime date1, Chat chat) {
		super();
		this.text = text;
		this.date1 = date1;
		this.chat = chat;
	}

	public Messages(String text, LocalDateTime date) {
		super();
		this.text = text;
		this.date1 = date1;
	}
	public Integer getMessage_Id() {
		return message_Id;
	}

	public void setMessage_Id(Integer message_Id) {
		this.message_Id = message_Id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public LocalDateTime getDate1() {
		return date1;
	}

	public void setDate(LocalDateTime date) {
		this.date1 = date1;
	}

	public Chat getChat() {
		return chat;
	}

	public void setChat(Chat chat) {
		this.chat = chat;
	}

	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((chat == null) ? 0 : chat.hashCode());
		result = prime * result + ((date1 == null) ? 0 : date1.hashCode());
		result = prime * result + message_Id;
		result = prime * result + ((text == null) ? 0 : text.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Messages other = (Messages) obj;
		if (chat == null) {
			if (other.chat != null)
				return false;
		} else if (!chat.equals(other.chat))
			return false;
		if (date1 == null) {
			if (other.date1 != null)
				return false;
		} else if (!date1.equals(other.date1))
			return false;
		if (message_Id != other.message_Id)
			return false;
		if (text == null) {
			if (other.text != null)
				return false;
		} else if (!text.equals(other.text))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Message [message_Id=" + message_Id + ", text=" + text + ", date=" + date1 + "]";
	}


	
}
