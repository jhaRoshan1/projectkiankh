package com.cg.capbook.services;

import java.util.List;


import com.cg.capbook.beans.Messages;

public interface MessageServices {

	public List<Messages> saveMessages(Messages messages);
	public List<Messages> getAllMessages(Messages messages);
	
	
}
