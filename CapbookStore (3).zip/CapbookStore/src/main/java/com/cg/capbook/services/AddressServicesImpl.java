package com.cg.capbook.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Address;
import com.cg.capbook.daoservices.AddressDao;
@Component("addressServices")
public class AddressServicesImpl implements AddressServices {
	@Autowired
	AddressDao addressDao;
	@Autowired
	UserProfileServices userProfileServices;
	
	@Override
	public Address acceptAddressDetails(int userId,Address address) {
		address.setUser(userProfileServices.getUserProfileDetails(userId));
		addressDao.save(address);
		return address;
	}

	@Override
	public Address getAddressDetails(int userId) {
		return null;
	}

	@Override
	public boolean updateAddressDetails(int userId, Address address) {
		address.setUser(userProfileServices.getUserProfileDetails(userId));
		addressDao.save(address);
		return true;
	}

	@Override
	public boolean deleteAddressDetails(int userId) {
		Address address=getAddressDetails(userId);
		addressDao.delete(address);
		return true;
	}

}
