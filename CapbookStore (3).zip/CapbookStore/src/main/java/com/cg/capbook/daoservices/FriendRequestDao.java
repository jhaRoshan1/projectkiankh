package com.cg.capbook.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capbook.beans.FriendRequest;

public interface FriendRequestDao extends JpaRepository<FriendRequest, Integer>{

}
