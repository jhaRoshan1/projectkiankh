package com.cg.capbook.services;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import org.hibernate.type.LocalDateType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capbook.beans.Chat;
import com.cg.capbook.beans.Messages;
import com.cg.capbook.beans.UserProfile;
import com.cg.capbook.daoservices.MessageDao;
@Component("messagesServices")
public class MessagesServicesImpl implements MessageServices{

	@Autowired
	MessageDao messageDao;
	
	LocalDateTime date1=LocalDateTime.now();
	
	
	/*
	 * public Messages AcceptMessages(String text,UserProfile user,Chat
	 * chat,Messages messages) {
	 * 
	 * messages.setText(text); messages.setDate(date1);
	 * 
	 * messages.setChat(chat);
	 * 
	 * }
	 */
	@Override
	public List<Messages> saveMessages(Messages messages) {
		
		messageDao.save(messages);
		return (List<Messages>) messages;
	}

	@Override
	public List<Messages> getAllMessages(Messages messages) {
		return messageDao.findAll();

	}



}
