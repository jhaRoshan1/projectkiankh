package com.cg.capbook.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cg.capbook.beans.Post;
import com.cg.capbook.beans.UserProfile;
@Controller
@SessionAttributes("user")
public class URIController {
	
	UserProfile user;

	 Post post; 
	@RequestMapping(value={"/","indexPage"})
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping(value= {"forgotPass"})
	public String getForgotPasswordPage() {
		return "forgotPasswordPage";
	}
	@RequestMapping(value= {"changePass"})
	public String getChangePasswordPage() {
		return "changePasswordPage";
	}
	@RequestMapping(value= {"home"})
	public String getHomePage() {
		return "profilePage";
	}
	
	@RequestMapping(value= {"chat"})
	public String getChatPage() {
		return "chatPage";
	}
	@RequestMapping(value= {"testImage"})
	public String getTestImagePage() {
		return "image";
	}
	@ModelAttribute("user")
	public UserProfile getUser() {
		user=new UserProfile();
		return user;
	}
	

	 @ModelAttribute("post") 
	 public Post getPost() {
	 post = new Post(); 
	 return  post; }
	 
}
